# -*- coding: utf-8 -*-
'''
Check production for solution 3. 
If found, report the max p and q mismatch busses
and their areas.
'''

global psyops
import psyops
from psyops.psy_str import space_split
global cfg
from soln3_fixer import soln3_config as cfg

#from psyops.psy_str import space_cleaner
#from psyops.psy_sys import sys_path_append

# -------------------------------------------------------------------
#  get psyops up and running
# -------------------------------------------------------------------

def report_from_log_file(file_in, type_conv=False):
    '''
    Fetch only the solution summary report from the bottom of the log file and
    parse the fixed width fields into a dataframe.  Return the dataframe.
    
    Parameters:
        file_in: the log file to read.  Must be a plain text file.
        regex_str: the string used to uniquely idenify a line from file_in
                   that contains a line from the solution summary table.
                   For all solutions: r'\d\d\ amb_solve\d\.dir'
                   For solution 3 only: r'\d\d\ amb_solve3.dir'
        file_out: If provided, the output dataframe, df,  is appended to csv 
                  file file_out and True is returned.
                  If not provided, the output dataframe, df, is returned.
    '''
    import datetime
    import re
    import pandas as pd
    from psyops.soln3_fixer import soln3_config as cfg
    from psyops.psy_list import data_type_list

    if cfg.verbose: 
        print('')
        print('---- parsing log_file: file: ' + file_in + '----')
        parse_start = datetime.datetime.now()

    snapshot = 0    
    snapshot_def = []
    snapshot_def_substr = r"------------------ Creating snapshot"

    non_converge = []
    non_converge_substr = "Fast Dec LF didn't converge"
    bus_mismatch = []
    bus_mism_dtl_substr = r"******************* Detailed bus flow analysis for"
    bus_mism_dtl = []

    soln_summary = []
    soln_summary_pattern = soln_summary_regex()
    
    k = file_in.split("_")[-1][0] #h, d, w, m or y
    if file_in[-6:-4] == '48': 
        k = 'H' #hourly 48
    non_cvg_line_num = -100
    bus_mism_dtl_line_num = -100
    for line_num, line in enumerate(open(file_in)):
        # snapshot definition       
        if snapshot_def_substr in line:
            #initialize for new snapshot
            snapshot = 0 
            non_cvg_line_num = -100
            bus_mism_dtl_line_num = -100
            # " ------------------ Creating snapshot 25 for  2016-05-03 00:00 ---------------"
            # word:    0              1        2     3   4     5          6        7
            temp = space_split(line)
            # snapshot_def_cols taken from config file:            
            #     ['log_line', 'snapshot num', 'snapshot datetime', 'hour']
            try:            
                snapshot = int(temp[3])
            except:    
                snapshot = str(temp[3])
            s = temp[5] + ' ' + temp[6]
            hr = s[-5:-3]
            try:
                dt = datetime.datetime.strptime(s,'%Y-%m-%d %H:%M')
            except:
                dt = s  
            temp = [[line_num, snapshot, dt, hr]]
            if type_conv:
                temp = data_type_list(temp, from_string=True )
            snapshot_def += [[line_num, snapshot, dt, hr]]
            if cfg.verbose: print(file_in +': snapshot ' + str(snapshot))
        # reports of non-convergence
        elif non_converge_substr in line and 'WarnID' not in line:
            # sample line from logfile:            
            # " day25. Fast Dec LF didn't converge in 60 iteration"
            #     0      2   2   3   4       5      6  7     8
        
            # non_converge_cols  from config file:
            #     [0:log_line, 1:snapshot num, 2:snapshot name, 3:num iterations, \
            #      4:tot_mismatch, 5: mismatch bus count, 6:tolerance]
            temp = space_split(line)
            temp = [line_num, snapshot, temp[0], \
                     temp[7], None, None, None]
            if type_conv:
                temp = data_type_list(temp, from_string=True )
            non_converge += [temp]
            non_cvg_line_num = line_num
            
        # non convergence bus mismatch summary
        if non_cvg_line_num == line_num:
            'skip section'
        elif line_num > non_cvg_line_num + 24:
            non_cvg_line_num = -100   #reset non_cvg_line_num
        elif 0 < non_cvg_line_num  and \
             non_cvg_line_num < line_num and line_num <= non_cvg_line_num + 25: # read 24 lines after non-convergence is reported
            # non_converge_cols  from config file:
            #     [0:log_line, 1:snapshot num, 2:snapshot name, 3:num iterations, \
            #      4:tot_mismatch, 5: mismatch bus count, 6:tolerance]
            if len(line.strip()) == 0:
                'skip blank line'
            elif 'totalAlgebMism' in line:  #find total mismatch
                # sample line from logfile:            
                #    " totalAlgebMism=141519.060"
                #  word:     0           1
                temp = line.split('=')  #split line on "=" sign.
                temp = [item.strip() for item in temp] # clean lead/lag spaces
                try:
                    non_converge[-1][4] = float(temp[1]) #total mismatch
                except:
                    non_converge[-1][4] = temp[1] #total mismatch
            elif 'buses with mismatch > tolerance' in line:
                # sample line from logfile:            
                #    " Total 7712 buses with mismatch > tolerance=   5.00000 "
                #  word: 0    1     2     3     4     5     6           7
                temp = space_split(line)
                try:
                    non_converge[-1][5] = int(temp[1]) # mismatch bus count
                    non_converge[-1][6] = int(temp[-1]) # tolerance
                except:
                    non_converge[-1][5] = temp[1] # mismatch bus count
                    non_converge[-1][6] = temp[-1] # tolerance
                if type_conv:
                    non_converge[-1] = data_type_list(non_converge[-1], from_string=True )
                if cfg.verbose:
                    print('non_converge[-1]: '+ str(non_converge_cols)) 
                    print(non_converge[-1])
                non_converge[-1][4] = temp[1] #total mismatch          
            elif non_cvg_line_num + 3 < line_num:
                try:  # only add lines where the first value is an integer
                    temp = int((line[0:6].strip())) #if not an integer, skip
                    bus_mismatch += [[line_num], [snapshot], [line[0:6],\
                                    line[7:13], line[14:26], \
                                    line[27:31], line[32:36], line[37:41],\
                                    line[43:55], line[56:68], line[69:81],\
                                    line[82:92], line[93:103], line[104:107],\
                                    line[108::111] ,line[112:115]]]
                    if type_conv:
                        bus_mismatch[-1] = data_type_list(bus_mismatch[-1], from_string=True )
                    if cfg.verbose:
                        print('bus_mismatch[-1]: ' + str(bus_mismatch_cols))
                        print(bus_mismatch[-1])
                except:
                    'Skip line, it does not conform to a row in the bus mismatch table '
            
        # non convergence bus mismatch details
        if bus_mism_dtl_substr in line:
            '''
             ******************* Detailed bus flow analysis for 314755 3SPOTSYL      115  345 DOM          1719 DVP          : *************
             word:    0             1      2   3      4      5     6     7            8    9   10           11   12          13 14                     
            '''
            temp = space_split(line)
            bus_num = temp[6]
            #bus_name = str(temp[7:-3]).strip("[']") 
            #bus_name = bus_name.replace("'"," ").replace("  "," ")   
            # non_converge_cols  from config file:
            #     [0:log_line, 1:snapshot num, 2:snapshot name, 3:num iterations, \
            #      4:tot_mismatch, 5: mismatch bus count, 6:tolerance]
            bus_mism_dtl_line_num = line_num
        elif line_num == bus_mism_dtl_line_num:
            'do nothing'
        elif line_num < bus_mism_dtl_line_num  or bus_mism_dtl_line_num > line_num + 5:
            bus_mism_dtl_line_num = -100
        else: #read first 5 lines of bus mismatch detail table
            '''            
            bus_mism_dtl_cols = ['log_line', 'snapshot', 'Bus Num', 'BusName', 'Volt', \
                     'Area', 'Zone', 'CKT', 'St', 'MW', 'MVAR', 'MVA', \
                     'V mag [PU]', 'V mag [kV]', 'V angle', 'Bus Type', \
                     'V Type', 'Type', 'Tap R', 'PS Angle', 'TAP R To', \
                     'branch R', 'branch X', 'branch Chr', 'Rate A', 'Rate B', \
                     'Rate C', 'Metered', 'Length', 'Reg Min', 'Reg Max', \
                     'Target Min', 'Target Max', 'MW metered  MVAR metered', \
                     'MVA metered', 'MW loss', 'MVAR loss']
            '''            
            if bus_mism_dtl_line_num < line_num  and line_num <= bus_mism_dtl_line_num + 5 :
                try:  # only add lines where the first value is an integer
                    bus_mism_dtl += [[line_num, snapshot, line[0:6],line[7:19],line[20:24]\
                                    ,line[25:29],line[30:34],line[35:39],\
                                    line[40:42],line[43:53],line[54:64],\
                                    line[65:75],line[76:86],line[87:97],\
                                    line[98:106],line[106:111],line[112:117],\
                                    line[117:123],line[124:131],line[132:139],\
                                    line[140:148],line[149:160],line[161:172],\
                                    line[173:184],line[185:192],line[193:200],\
                                    line[201:208],line[208:213],line[214:221],\
                                    line[222:232],line[233:239],line[240:248],\
                                    line[249:257],line[258:269],line[270:279],\
                                    line[280:290],line[291:301],line[302:312]]]
                except:
                    try:  # only add lines where the first value is an integer
                        bus_mism_dtl += [[line_num, snapshot, bus_num ,line[7:19],line[20:24]\
                                        ,line[25:29],line[30:34],line[35:39],\
                                        None, None, None,\
                                        None, None, None,\
                                        None, None, None,\
                                        None, None, None,\
                                        None, None, None,\
                                        None, None, None,\
                                        None, None, None,\
                                        None, None, None,\
                                        None, None, None,\
                                        None, None, None]]
                    except:
                        'Skip line, it does not conform to a row in the bus mismatch details table '
                if type_conv:
                    bus_mism_dtl[-1] = data_type_list(bus_mism_dtl[-1], from_string=True )
                    
        #solution summary table
        if k == 'H':
            for match in re.finditer(soln_summary_pattern, line):
                soln_summary+=[[line_num,line[0:4],line[4:6],line[8:11],line[14:16],line[18:21],\
                    line[26:31],line[32:39],line[39:52],line[53:57],\
                    line[60:67],line[72:77],line[78:85], line[86:98],\
                    line[99:103],line[106:113],line[113:128]]]
                if type_conv:
                    soln_summary[-1] = data_type_list(soln_summary[-1], from_string=True )
        elif k == 'h' or k == 'w' or k == 'y':
            for match in re.finditer(soln_summary_pattern, line):
                if line[:6] != 'hour46' and line[:6] != "hour47" and line[:6] != "hour48":
                    soln_summary+=[[line_num,line[0:4],line[4:7],line[9:12],line[15:17],line[19:22],\
                        line[27:32],line[33:40],line[40:53],line[54:58],\
                        line[61:68],line[73:78],line[79:86], line[87:99],\
                        line[100:104],line[107:114],line[114:129]]]
                    if type_conv:
                        soln_summary[-1] = data_type_list(soln_summary[-1], from_string=True )
        elif k == 'd':
            for match in re.finditer(soln_summary_pattern, line):
                soln_summary+=[[line_num,line[0:3],line[3:5],line[7:10],line[13:15],line[17:20],\
                    line[25:30],line[31:38],line[38:51],line[52:56],\
                    line[59:66],line[71:76],line[77:84], line[85:97],\
                    line[97:102],line[105:112],line[112:127]]]
                if type_conv:
                    soln_summary[-1] = data_type_list(soln_summary[-1], from_string=True )
        elif k == 'm':
            for match in re.finditer(soln_summary_pattern, line):
                soln_summary+=[[line_num,line[0:5],line[5:7],line[9:12],line[15:17],line[19:22],\
                    line[27:32],line[33:40],line[41:53],line[53:58],\
                    line[61:68],line[73:78],line[79:86], line[87:99],\
                    line[99:104],line[107:114],line[114:129]]]
                if type_conv:
                    soln_summary[-1] = data_type_list(soln_summary[-1], from_string=True )
    else:
        'do nothing'

    if cfg.verbose: 
        print('')
        parse_stop = datetime.datetime.now()
        print('---- Finished data type conversion: ' + (parse_stop - parse_start).strftime("%H:%M:%S") + ' ----')


    if type_conv:
        if cfg.verbose: 
            print('')
            tc_start = datetime.datetime.now()
            print('---- Start data type conversion ----')
        non_converge = data_type_list(non_converge, from_string=True )
        bus_mismatch = data_type_list(bus_mismatch, from_string=True )
        bus_mism_dtl = data_type_list(bus_mism_dtl, from_string=True )
        soln_summary = data_type_list(soln_summary, from_string=True )
        if cfg.verbose: 
            print('')
            tc_stop = datetime.datetime.now()
            print('---- Finished data type conversion: ' + (tc_stop - tc_start).strftime("%H:%M:%S") + ' ----')
        
    if cfg.verbose: 
        print('solution rows: ' + str(len(soln_summary)))
        parse_stop = datetime.datetime.now()
        t = parse_stop - parse_start
        print('parsing time (days, seconds): ' + str(divmod(t.days * 86400 + t.seconds, 60)))

    # return results and optionally write to file(s)
    fo = pathfile_out()

    if cfg.verbose: 
        print('')
        store_start = datetime.datetime.now()
        print('---- Start storing (or returning) results ----')
    snapshot_def_df = pd.DataFrame(columns=cfg.snapshot_def_cols)
    if len(soln_summary) > 0 and len(soln_summary) == len(cfg.snapshot_def_cols):
        soln_summary_df = pd.DataFrame(soln_summary, columns=cfg.snapshot_def_cols)
        if len(fo)>1:
            snapshot_def_df.to_csv(fo, index=False, delim_whitespace=True) 

    bus_mismatch_df = pd.DataFrame(columns=cfg.bus_mismatch_cols)
    if len(soln_summary) > 0 and len(soln_summary) == len(cfg.bus_mismatch_cols):
        soln_summary_df = pd.DataFrame(soln_summary, columns=cfg.bus_mismatch_cols)
        if len(fo)>1:
            bus_mismatch_df.to_csv(fo, index=False, delim_whitespace=True) 

    bus_mism_dtl_df = pd.DataFrame(columns=cfg.soln_summary_cols)
    if len(soln_summary) > 0 and len(soln_summary) == len(cfg.bus_mism_dtl_cols):
        soln_summary_df = pd.DataFrame(soln_summary, columns=cfg.bus_mism_dtl_cols)
        if len(fo)>1:
            bus_mism_dtl_df.to_csv(fo, index=False, delim_whitespace=True) 

    soln_summary_df = pd.DataFrame(columns=cfg.soln_summary_cols)
    if len(soln_summary) > 0 and len(soln_summary) == len(cfg.soln_summary_cols):
        soln_summary_df = pd.DataFrame(soln_summary, columns=cfg.soln_summary_cols)
        if len(fo)>1:
            soln_summary_df.to_csv(fo, index=False, delim_whitespace=True) 

    if cfg.verbose: 
        print('')
        store_stop = datetime.datetime.now()
        print('---- Finished storing (or returning) results: ' + (store_stop - store_start).strftime("%H:%M:%S") + ' ----')

        print('')
        store_stop = datetime.datetime.now()
        print('---- Finished report_from_log_file().  Run time: ' + (store_stop - parse_start).strftime("%H:%M:%S") + ' ----')
    

def pathfile_out():
    from soln3_fixer import soln3_config as cfg
    from os.path import join
    if '\\' in cfg.file_out or '/' in cfg.file_out:
        return cfg.file_out
    elif len(cfg.file_out) > 1:
        return join(cfg.dir_out, cfg.file_out)
    else:
        return

def soln_report_from_log_file(file_in):
    '''
    Fetch only the solution summary report from the bottom of the log file and
    parse the fixed width fields into a dataframe.  Return the dataframe.
    
    Parameters:
        file_in: the log file to read.  Must be a plain text file.
        regex_str: the string used to uniquely idenify a line from file_in
                   that contains a line from the solution summary table.
                   For all solutions: r'\d\d\ amb_solve\d\.dir'
                   For solution 3 only: r'\d\d\ amb_solve3.dir'
        file_out: If provided, the output dataframe, df,  is appended to csv 
                  file file_out and True is returned.
                  If not provided, the output dataframe, df, is returned.
    '''
    import datetime
    import re
    import pandas as pd

    if cfg.verbose: 
        print('')
        print('---- soln_report_from_log_file: begin file parsing: ' + file_in + '----')
        parse_start = datetime.datetime.now()
    soln_summary = []
    soln_summary_pattern = soln_summary_regex()
    k = file_in.split("_")[-1][0] #h, d, w, m or y
    if file_in[-6:-4] == '48': 
        k = 'H' #hourly 48
    if k == 'H':
        for line_num, line in enumerate(open(file_in)):
            for match in re.finditer(soln_summary_pattern, line):
                soln_summary+=[line_num, None, line[0:4],line[4:6],line[8:11],line[14:16],line[18:21],\
                    line[26:31],line[32:39],line[39:52],line[53:57],\
                    line[60:67],line[72:77],line[78:85], line[86:98],\
                    line[99:103],line[106:113],line[113:128]]
    elif k == 'h' or k == 'w' or k == 'y':
        for line_num, line in enumerate(open(file_in)):
            for match in re.finditer(soln_summary_pattern, line):
                if line[:6] != 'hour46' and line[:6] != "hour47" and line[:6] != "hour48":
                    soln_summary+=[line_num, None, line[0:4],line[4:7],line[9:12],line[15:17],line[19:22],\
                        line[27:32],line[33:40],line[40:53],line[54:58],\
                        line[61:68],line[73:78],line[79:86], line[87:99],\
                        line[100:104],line[107:114],line[114:129]]
    elif k == 'd':
        for line_num, line in enumerate(open(r'K:\AFC Model Solution Logs\log\log_daily.txt')):
            for match in re.finditer(soln_summary_pattern, line):
                soln_summary+=[line_num, None, line[0:3],line[3:5],line[7:10],line[13:15],line[17:20],\
                    line[25:30],line[31:38],line[38:51],line[52:56],\
                    line[59:66],line[71:76],line[77:84], line[85:97],\
                    line[97:102],line[105:112],line[112:127]]
    elif k == 'm':
        for line_num, line in enumerate(open(r'K:\AFC Model Solution Logs\log\log_monthly.txt')):
            for match in re.finditer(soln_summary_pattern, line):
                soln_summary+=[line_num, None, line[0:5],line[5:7],line[9:12],line[15:17],line[19:22],\
                    line[27:32],line[33:40],line[41:53],line[53:58],\
                    line[61:68],line[73:78],line[79:86], line[87:99],\
                    line[99:104],line[107:114],line[114:129]]
    else:
        'do nothing'
        
    if cfg.verbose: 
        print('solution rows: ' + str(len(soln_summary)))
        parse_stop = datetime.datetime.now()
        t = parse_stop - parse_start
        print('parsing time (days, seconds): ' + str(divmod(t.days * 86400 + t.seconds, 60)))
    soln_summary_cols = cfg.soln_summary_cols
    if len(soln_summary) == 0:
        df = pd.DataFrame(columns=soln_summary_cols)
    if len(soln_summary) == len(cfg.soln_summary_cols):
        fo = pathfile_out()
        df = pd.DataFrame(soln_summary, columns=soln_summary_cols)
        if len(fo)>1:
            df.to_csv(fo, index=False, delim_whitespace=True) 
            return True
        else:
            return df
    else:
        df = None
        return df

def soln_summary_regex(regex_str='auto'):
    import re
    from soln3_fixer import soln3_config as cfg
    if regex_str == 'auto' or len(regex_str) == 0:
        if cfg.soln_num == 0:
            regex_str = r'\d\d\ amb_solve\d\.dir'
        else:
            regex_str = r'\d\d\ amb_solve' + cfg.soln_num + '.dir'
    return re.compile(regex_str)
# -------------------------------------------------------------------
# The one function that rules them all.
# -------------------------------------------------------------------
def soln_reports(from_server=False, soln_level=0, to_file=False):
    import os
    import shutil
    #import sys
    #import pandas as pd

    soln_level    
    
    global soln_rpt
    from psyops import psy_file as pf  # Advena's python library for lazy power systems engineers
    global cfg
    from soln3_fixer import soln3_config as cfg
    #sys_path_append('psy_readme.txt') # imports psyops library
    #global psyops
    #import psyops
    #global soln3_fixer
    #from psyops import soln3_fixer
     # initialize
    soln_rpt=[]
	# Find the log files
    log_file_list = pf.find_files(root_path=cfg.dir_server, \
                               pattern=cfg.regex_file_pattern, \
                               recursive=False) # get list of log files
    server_file_list = [os.path.join(cfg.dir_server, fname) for fname in log_file_list]
    working_file_list = [os.path.join(cfg.dir_working, fname) for fname in log_file_list]
    # copy the files to dir_working
    soln_rpt=[]
    for file_num in range(len(server_file_list)):
        try:
            srv_file = server_file_list[file_num]
            wrk_file = working_file_list[file_num]
        except:
            if cfg.verbose: print('Unexpected Error')
            return [-1,'Error.  Unable to read from file list.']
        if from_server: 
            try:
                os.remove(wrk_file)
                if cfg.verbose: print("deleted old file : " + str(wrk_file))
            except:
                "do nothing"
            try:
                shutil.copy(srv_file, cfg.dir_working)
                if cfg.verbose: print("copied: " + str(srv_file) + " to " + str(wrk_file)    )
            except:
                return [-2,'Unable to copy log file from server to working directory.']
        else:
            if cfg.verbose: print("using files in working directory")

        soln_rpt += [report_from_log_file(wrk_file)]
        #soln_rpt += [soln_report_from_log_file(wrk_file)]
    
    return soln_rpt


# -------------------------------------------------------------------
# allow execution as command line script: python soln3_fixer.py
# -------------------------------------------------------------------
if __name__ == "__main__":
    #def read_config(cfg_file = 'soln3_fixer.cfg'):
    '''
    read_config - reads in configuration file if run from command line
    Default execution is of soln3_fixer.cfg in current directory.  All
    items from read_config are set to global variables.

    The soln3_fixer.cfg file is expected in:
    {python install folder}\Lib\site-packages\psyops\soln3_fixer.cfg.
    
    '''
    print soln_reports(False, to_file=True)
    
#print('soln3_fixer(True)')
#soln3_fixer(False,)