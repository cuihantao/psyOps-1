# -*- coding: utf-8 -*-
"""
Created on Wed Apr 13 08:12:19 2016
@author: advena

'''
List of functions:
  sort_unique(list): returns sorted list with no dupes
  quick_unique(list): returns list with no dupes
  quicker_unique(list): elimiates dupes IN PLACE
  cheap_sort: sorts list IN PLACE
  quick_sort: returns sorted list
  dupes: returns pairs of list items and count of ocurrences

  list_examples(): demos the functions in this module
"""

# ----------------------------------------------------------------------------    
#  Function definitions
# ----------------------------------------------------------------------------    

def sort_unique(seq):
    return quick_sort(quick_unique(seq))
    
def quick_unique(seq):
    ### Filter to unique list maintaining order
    ### Fast optioin 
    ### Why assign seen.add to seen_add instead of just calling seen.add? Python 
    ### is a dynamic language, and resolving seen.add each iteration is more 
    ### costly than resolving a local variable. seen.add could have changed 
    ### between iterations, and the runtime isn't smart enough to rule that out. 
    ### To play it safe, it has to check the object each time.    
    ### See also: https://www.peterbe.com/plog/uniqifiers-benchmark
    if len(seq)>0:
        seen = set()
        seen_add = seen.add
        return [x for x in seq if not (x in seen or seen_add(x))]
    else:
        return seq

def quicker_unique(seq):
    # More than 2x faster than list_unique(), above but
    # does NOT preserve order
    if len(seq)>0:
        return {}.fromkeys(seq).keys()
    else:
        return seq

def cheap_sort(array):
    # quick sort IN PLACE function, which uses less memory.
    # source: http://rosettacode.org/wiki/Sorting_algorithms/quick_sort#Python
    #
    _cheap_sort(array, 0, len(array) - 1)
 
def _cheap_sort(array, start, stop):
    if stop - start > 0:
        pivot, left, right = array[start], start, stop
        while left <= right:
            while array[left] < pivot:
                left += 1
            while array[right] > pivot:
                right -= 1
            if left <= right:
                array[left], array[right] = array[right], array[left]
                left += 1
                right -= 1
        _cheap_sort(array, start, right)
        _cheap_sort(array, left, stop)
        
def quick_sort(inlist):
    ''' 
    quick_sort is a sorting option that can be used as an
    alternative to the built in list method .sort().
    '''
    if inlist == []: 
        return []
    else:
        pivot = inlist[0]
        lesser = quick_sort([x for x in inlist[1:] if x < pivot])
        greater = quick_sort([x for x in inlist[1:] if x >= pivot])
        return lesser + [pivot] + greater

def dupes(lst, preserve_order=True):
    ret=[]
    #try:
    #    lst = list[lst]
    #except Exception, e:
    #    print('psy_list.counts() error.  ' + str(e))
    #    return 
    if preserve_order:
        unq = quick_unique(lst)
    else:
        unq = set(lst)
    for item in unq:
        ret += [[item, lst.count(item)]]
    return ret

def data_type_list(list_in, date_fmts=['%m/%d/%Y', '%m/%d/%y', \
                                    '%m/%d/%Y %H:%M', '%m/%d/%y %H:%M', \
                                    '%m/%d/%Y %H:%M:%S', '%m/%d/%y %H:%M:%S', \
                                    '%Y-%m-%d %H:%M'], \
                 from_string=False):
    ''' 
    Attempts to auto convert each item from a list to native python data type.
    Performs recursively, that is, it will continue through sub-lists.
    
    Returns a list.
    
    Input Paramters:
        list_in: a list-like object
        date_fmts: a list of date formats you expect.
                   If date format is unknown, submit an empty list.  
                   If an empty list is given, then dateutil.parser parse
                   is used to automatically attempt to find a date format.  
                   Beware that using dateutil.parser will be expensive and
                   could convert some values to date that were not intended
                   to be dates.
        from_string: set to True to force the list items (excluding sub-lists
                     and tuples) to be set to str(list item).strip() before 
                     attempting to set type.  This is useful if you are
                     setting types for a list of parsed string data.
    '''
    import datetime
    from dateutil.parser import parse
    
    # if needed, convert fmts to a list
    if isinstance(date_fmts, list):
        'skip ahead'    
    if isinstance(date_fmts, tuple):
        date_fmts=list(date_fmts)    
    elif isinstance(date_fmts, int) or \
          isinstance(date_fmts, float) or \
          isinstance(date_fmts, datetime.datetime):
        date_fmts=[date_fmts]
    else:
        try:
            # python 2
            if isinstance(date_fmts, basestring):
                date_fmts=[date_fmts]
        except:
            # python 3
            if isinstance(date_fmts, str):
                date_fmts=[date_fmts]
    
    #  begin converting data types
    ret = []    
    for item in list_in:
        if isinstance(item, tuple): #convert tuple to list before continuing
            item = list[item]
        if isinstance(item, list):  # recurse if item is a list
            ret += [data_type_list(item)]
        else:
            if from_string:
                try:
                    item=str(item).strip()
                except:
                    "Cannot convert item to string.  That's odd"
            try:
                ret += [int(item)]
            except:
                try:
                    ret += [float(item)]
                except:
                        typed = False
                        if len(date_fmts) == 0:  # auto-detect date format
                            try: 
                                ret += [parse(item)]
                                typed = True
                            except:
                                typed = False
                        else:
                            for fmt in date_fmts:
                                try:
                                    ret += [datetime.datetime.strptime(item,fmt)]
                                    typed = True
                                    break
                                except:
                                    typed = False
                        if not typed:
                            ret += [item]
    return ret



# ----------------------------------------------------------------------------    
#  Example us of functions in this module (and some builtins)
# ----------------------------------------------------------------------------    

def list_examples():
    mylist = [9,4,8,9,4,21,45,8,0,7,3,32,6,-45,776,3]
    print(mylist)
    print('')
    print('count duplicates with dupes():')
    print(dupes(mylist))
    print('')
    print('eliminate duplicates with quick_unique():')
    print(quick_unique(mylist))
    print('')
    print('eliminate duplicates with quicker_unique():')
    print(quicker_unique(mylist))
    print('')
    print('eliminate duplicates and sort with sort_unique():')
    print(sort_unique(mylist))
    print('')
    print('sorted in place with builtin .sort(): ' )
    print(sort_unique(mylist))
    print('')
    print('sort with quick_sort: ' )
    print(quick_sort(mylist))
    print('')
    print('sort IN PLACE with cheap_sort: ' )
    print(cheap_sort(mylist))
    print('')
    print('sorted in place with builtin .sort(): ' )
    mylist.sort()


# ----------------------------------------------------------------------------    
#  Testing
# ----------------------------------------------------------------------------    

# need to add testing for this module
#list_examples()