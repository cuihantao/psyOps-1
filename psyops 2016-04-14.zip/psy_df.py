# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 16:43:35 2016

@author: advena
"""

def df_dupes(df_in):
    '''
    Returns [object,count] pairs for each unique item in the dataframe.    
    '''
    # import pandas
    if isinstance(df_in, list) or isinstance(df_in, tuple):
        import pandas as pd
        df_in = pd.DataFrame(df_in)
    return df_in.groupby(df_in.columns.tolist(),as_index=False).size()

def df_filter(df_in, sub_str, col_index=-1): # soln_text
    '''
    filter a python list using a regular expression
    
    parameters
        df_in: 2-dimensional list-like item  to be filtered.
        reges_str: regular expression (before compile)
    
    '''
    import pandas as pd
    import re
    testing = True   # print extra data to the console for debugging
    if testing: 
        print('')        
        print('df_filter starting')   
        print('    sub_str: ' + sub_str)
        print('    df_in rows: ' + str(len(df_in)))
    lst=[]
    for index, row in enumerate(df_in.values):
        pattern = re.compile(sub_str)
        if sub_str in (str(row[int(col_index)])):
            lst += [row]
    col_names = ['Interval','Iterations','Pms','Qms','P_Mismatch','P_Bus#','P_BusName','P_Volt','P_VoltMagPU',\
             'QmaxMism','Q_Bus#','Q_BusName','Q_Volt','Q_VoltMagPU','Solution Attempt']
    df_out = pd.DataFrame(lst, columns=col_names)

    if testing: print('df_filter finished.  return rows: '  + str(len(df_out)))   
    return df_out   