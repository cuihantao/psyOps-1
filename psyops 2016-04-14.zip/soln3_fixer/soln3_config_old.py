# soln3_fixer.cfg contains settings for the soln3_fixer.py script
#
# Comments must start with # as the first character position 
#     and must be on a separate line from settings.


# Source directory where ATC log files are stored
#     dir_source = '\\Oas02awp\pti\ATCPJM\log'  
#     dir_source = 'K:\AFC Model Solution Logs\log'
global dir_source  
dir_source = r'K:\AFC Model Solution Logs\log'

# Filter pattern (regex) for collecting the log files from dir_source
# regex_file_patternoptions  'h*log_*ly.txt' , 'd*log_*ly.txt' , 
#                            'w*log_*ly.txt' , 'm*log_*ly.txt' ,
#                            'y*log_*ly.txt' , '*log_*ly.txt'
global regex_file_pattern
regex_file_pattern = '*log_*ly.txt'   

# Regular expression to identify rows in the solution summary table (located  
#   near the end of the log file)
# Begin DO NOT CHANGE
global regex_soln 
regex_soln0 = r'\d\d\ amb_solve\d\.dir'     
regex_soln3 = r'\d\d\ amb_solve1.dir'     
regex_soln3 = r'\d\d\ amb_solve2.dir'     
regex_soln3 = r'\d\d\ amb_solve3.dir' 
# End DO NOT CHANGE

# set regex_soln = regex_soln0, regex_soln1, regex_soln2 or regex_soln3
#   regex_soln0 - return summary for all solutions
#   regex_soln1 - return summary for solution 1 only
#   regex_soln2 - return summary for solution 2 onlyns
#   regex_soln3 - return summary for solution 3 onlys
regex_soln = regex_soln0
#'\d\d\ amb_solve\d\.dir'

global soln_text
soln_text = r'\amb_sol'     

# Temporary directory used by soln3_fixer.py script.
# r'c:/temp/', r'K:\AFC Model Solution Logs', etc.
global dir_working
dir_working = r'c:/temp/'

# output directory for output to be saved.
# r'c:/temp/', r'K:\AFC Model Solution Logs', etc.
global dir_out
dir_out = dir_working    

# directory where output will be saved
# filename only, no path     
global file_out
file_out = 'Hourly Solutions.csv'  

# The 16 column headers for the solution summary table.
# recommended: summary_cols = ['Increment', 'Interval','Iterations','Pms','Qms',\
#             'P_Mismatch','P_Bus#','P_BusName','P_Volt','P_VoltMagPU',\
#             'QmaxMism','Q_Bus#','Q_BusName','Q_Volt','Q_VoltMagPU',\
#             'Solution Attempt']
# alternative: "summary_cols= None" # to auto-calc column widths.
global summary_cols
summary_cols = ['log_line','Increment', 'Interval','Iterations','Pms','Qms',\
             'P_Mismatch','P_Bus#','P_BusName','P_Volt','P_VoltMagPU',\
             'QmaxMism','Q_Bus#','Q_BusName','Q_Volt','Q_VoltMagPU',\
             'Solution Attempt']


# The 16 column headers for the solution summary table.
global col_specs
col_specs ={'y': [[0,4],[4, 8], [8, 13], [13, 23], [23, 33], [33, 41], [79, 87], \
                  [45, 47], [47, 59], [59, 69], [69, 79], [79, 87], \
                  [87, 92], [92, 105], [105, 115], [115, 130], [130, 133]], \
            'h': [[0,4],[4, 8], [8, 13], [13, 23], [23, 33], [33, 41], [41, 45],\
                 [45, 47], [47, 59], [59, 69], [69, 79],  [79, 87], [87, 92], \
                 [92, 105], [105, 115], [115, 130], [130, 133]], \
            'm': [[0,5],[5, 9], [9, 14], [14, 24], [24, 34], [34, 42], [42, 46], \
                  [46, 48], [48, 60], [60, 70], [70, 80], [80, 88], \
                  [88, 93], [93, 106], [106, 116], [116, 131], [131, 134]], \
            'd': [[0,3],[3, 7], [7, 12], [12, 22], [22, 32], [32, 40],[40, 44],\
                  [44, 46], [46, 58], [58, 68], [68, 78], [78, 86], \
                  [86, 91], [91, 104], [104, 114], [114, 129], [129, 132]], \
            'w': [[0,4],[4, 8], [8, 13], [13, 23], [23, 33], [33, 41], [41, 45], \
                  [45, 47], [47, 59], [59, 69], [69, 79], [79, 87], \
                  [87, 92], [92, 105], [105, 115], [115, 130],  [130, 133]]}
