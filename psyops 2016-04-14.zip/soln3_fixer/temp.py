# -*- coding: utf-8 -*-
"""
Created on Tue Apr 12 16:11:27 2016

@author: advena
"""

import sys
sys.path.append('c:\python27\lib\site-packages\psyops\soln3_fixer')
import soln3_config
#soln3_fixer_config.init()
#print soln3_fixer_config.col_specs

print soln3_config.dir_out