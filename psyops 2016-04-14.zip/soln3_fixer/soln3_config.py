# soln3_fixer.cfg contains settings for the soln3_fixer.py script

# ---------------------------------------------------------------------------
#                    ----------- Instructions -----------                   
# ---------------------------------------------------------------------------
#
# At a minimum, review and update the following settings:
#     soln_num, dir_server, dir_server, and dir_out
#
# Comments must start with # as the first character position 
# and must be on a separate line from settings.
#
# Use a backslash (\) to continue a statement on the next line.
#
# psyops library (see Chris Advena) must be installed for soln3_fixer to
# function properaly.  


# ---------------------------------------------------------------------------
#                          Report filter criteria
# ---------------------------------------------------------------------------
# Regular expression to identify rows in the solution summary table (located  
#   near the end of the log file)
# Begin DO NOT CHANGE
# set 
#    soln_num = 0 for all solutions
#    soln_num = 1 for solution 1 only
#    soln_num = 2 for solution 2 only
#    soln_num = 3 for solution 3 only
global soln_num
soln_num = 0

# Location of the psyops python library.  See Chris Advena.
# located on network share: "\\corp\shares\TransmissionServices\TSD, Shared Interest\Misc\Code\Python\psyops"
global psyops_path  #used under Misc section at the bottom.
psyops_path = r'c:\python27\lib\site-packages\psyops'
# psyops_path = r"\\corp\shares\TransmissionServices\TSD, Shared Interest\Misc\Code\Python\psyops"


# ---------------------------------------------------------------------------
#                              Directories
# ---------------------------------------------------------------------------

# Source directory where ATC log files are stored
#     dir_server = '\\Oas02awp\pti\ATCPJM\log'  
#     dir_server = 'K:\AFC Model Solution Logs\log'
global dir_server  
dir_server = r'K:\AFC Model Solution Logs\log'

# Temporary directory used by soln3_fixer.py script.
# r'c:/temp/', r'K:\AFC Model Solution Logs', etc.
global dir_server
dir_working = r'c:/temp/'

# output directory for output to be saved.
# r'c:/temp/', r'K:\AFC Model Solution Logs', etc.
global dir_out
dir_out = dir_working    

# directory where output will be saved
# filename only, no path     
global file_out
file_out = 'AFC Solutions Report.csv'  

# ---------------------------------------------------------------------------
#                                 RegEx filters
# ---------------------------------------------------------------------------

# Filter pattern (regex) for collecting the log files from dir_server
# regex_file_patternoptions  'h*log_*ly.txt' , 'd*log_*ly.txt' , 
#                            'w*log_*ly.txt' , 'm*log_*ly.txt' ,
#                            'y*log_*ly.txt' , '*log_*ly.txt'
global regex_file_pattern
regex_file_pattern = '*log_*ly.txt'   

# soln_summary_pattern must be a regular expression (regex)
global soln_summary_pattern
soln_summary_pattern = r'\d\d\ amb_solve\d\.dir'

# ---------------------------------------------------------------------------
#                               Simple filters
# ---------------------------------------------------------------------------

global snapshot_def_substr
snapshot_def_substr = r"------------------ Creating snapshot "

global non_converge_substr
non_converge_substr = r". Fast Dec LF didn't converge in "

global bus_mism_dtl_substr
bus_mism_dtl_substr = r"******************* Detailed bus flow analysis for"

# ---------------------------------------------------------------------------
#                            Column headers
# ---------------------------------------------------------------------------

# The 16 column headers for the solution summary table.
# recommended: soln_summary_cols = ['Increment', 'Interval','Iterations','Pms','Qms',\
#             'P_Mismatch','P_Bus#','P_BusName','P_Volt','P_VoltMagPU',\
#             'QmaxMism','Q_Bus#','Q_BusName','Q_Volt','Q_VoltMagPU',\
#             'Solution Attempt']
# alternative: "soln_summary_cols= None" # to auto-calc column widths.
global soln_summary_cols
soln_summary_cols = ['log_line','Increment', 'Interval','Iterations','Pms','Qms',\
             'P_Mismatch','P_Bus#','P_BusName','P_Volt','P_VoltMagPU',\
             'QmaxMism','Q_Bus#','Q_BusName','Q_Volt','Q_VoltMagPU',\
             'Solution Attempt']

global non_converge_cols
non_converge_cols = ['log_line', 'snapshot num', 'snapshot name', \
                     'num iterations', 'tot_mismatch', 'mismatch bus count', \
                     'tolerance']

global snapshot_def_cols
snapshot_def_cols = ['log_line', 'snapshot num', 'snapshot datetime', 'hour']

global bus_mismatch_cols
bus_mismatch_cols = ['log_line', 'snapshot', 'ibus', 'Bus Num', 'Bus Name', 'Volt', \
                     'Area Num', 'Zone Num', 'Mismatch Magnitude', \
                     'P Mismatch', 'Q Mismatch', 'V Magnitude', \
                     'V Angle', 'V Low', 'V OK', 'V High']

global bus_mism_dtl_cols                     
bus_mism_dtl_cols = ['log_line', 'snapshot', 'Bus Num', 'BusName', 'Volt', \
                     'Area', 'Zone', 'CKT', 'St', 'MW', 'MVAR', 'MVA', \
                     'V mag [PU]', 'V mag [kV]', 'V angle', 'Bus Type', \
                     'V Type', 'Type', 'Tap R', 'PS Angle', 'TAP R To', \
                     'branch R', 'branch X', 'branch Chr', 'Rate A', 'Rate B', \
                     'Rate C', 'Metered', 'Length', 'Reg Min', 'Reg Max', \
                     'Target Min', 'Target Max', 'MW metered  MVAR metered', \
                     'MVA metered', 'MW loss', 'MVAR loss']

# ---------------------------------------------------------------------------
#                            Misc
# ---------------------------------------------------------------------------

# Dump more print() statements to the python console.
global verbose
verbose = True

# Take extra time to attempt to convert all the parsed data from strings
# to proper python data types.  Exptect this to extend processing time.
global type_conv
type_conv = False

# Import required psyops library, so that soln3_fixer will work.
import sys
sys.path.append(psyops_path)  # psyops_path defined up top.
global psyops
import psyops   # Used in soln3_fixer.py, which runs/requires this py file.