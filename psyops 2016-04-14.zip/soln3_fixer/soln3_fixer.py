# -*- coding: utf-8 -*-
'''
Check production for solution 3. 
If found, report the max p and q mismatch busses
and their areas.
'''

# -------------------------------------------------------------------
#  get psyops up and running
# -------------------------------------------------------------------
def me_path(file_name='psy_readme.txt'):
    '''
    me_path() returns the path in which parameter file_name is found.
    specify a filename that can only be found in his python script's
    root folder 
    '''
    import sys
    import os
    from fnmatch import filter    
    for sf in [r'Lib\site-packages\psyops', 'Lib', '']:
        try:
            ret=[]
            for base, dirs, files in os.walk(os.path.join(sys.exec_prefix, sf)):
                goodfiles = filter(files, file_name)
                ret.extend(os.path.join(base, f) for f in goodfiles)
            return ret[0][:-15]
        except:
            'try again'

    
def sys_path_append(file_name='psy_readme.txt'):
    '''
    sys_path_append() loads this python scripts path into sys.path 
    '''
    from os import path
    new_path = me_path(file_name)    
    try:
        path.index(new_path)
    except:
        try:
            path.append(new_path)
            sys.path.append(new_path)
        except:
            print('Unable to to import required psyops library.  Script will fail.')
            return False
    # remove duplicates from sys.path 
    seen = set()
    seen_add = seen.add
    sys_path = [x for x in sys.path if not (x in seen or seen_add(x))]
    sys.path = sys_path
    return True

'''
sys_path_append('psy_readme.txt') # imports psyops library
global psyops
import psyops
sys_path_append('soln_config.py') # imports soln3_fixer library
global soln3_fixer
import soln3_fixer
'''


'''
Initialize psyops defined globals (not found in config file)
'''

def soln_report_from_log_file(file_in, regex_str=r'\d\d\ amb_solve\d\.dir', file_out=''):
    testing = True
    import datetime
    import re
    import pandas as pd

    if testing: 
        print('')
        print('---- soln_report_from_log_file: begin file parsing: ' + file_in + '----')
    parse_start = datetime.datetime.now()
    lst = []
    '''df = pd.DataFrame(columns=['Increment','Iterations','Pms','Qms',\
         'P_Mismatch','P_Bus#','P_BusName','P_Volt','P_VoltMagPU',\
         'QmaxMism','Q_Bus#','Q_BusName','Q_Volt','Q_VoltMagPU',\
         'Solution Attempt'])'''
    pattern = re.compile(regex_str)
    k = file_in.split("_")[-1][0] #h, d, w, m or y
    if file_in[-6:-4] == '48': 
        k = 'H' #hourly 48
    if k == 'H':
        for i, line in enumerate(open(file_in)):
            for match in re.finditer(pattern, line):
                #print(line)
                lst+=[[line[4:6],line[8:11],line[14:16],line[18:21],\
                    line[26:31],line[32:39],line[39:52],line[53:57],\
                    line[60:67],line[72:77],line[78:85], line[86:98],\
                    line[99:103],line[106:113],line[113:128]]]
    elif k == 'h' or k == 'w' or k == 'y':
        for i, line in enumerate(open(file_in)):
            for match in re.finditer(pattern, line):
                #print(line)
                if line[:6] != 'hour46' and line[:6] != "hour47" and line[:6] != "hour48":
                    lst+=[[line[4:7],line[9:12],line[15:17],line[19:22],\
                        line[27:32],line[33:40],line[40:53],line[54:58],\
                        line[61:68],line[73:78],line[79:86], line[87:99],\
                        line[100:104],line[107:114],line[114:129]]]
        #frame = pd.DataFrame(lst, columns=['Hour','Iterations','Pms','Qms','P_Mismatch','P_Bus#','P_BusName','P_Volt','P_VoltMagPU',\
        #                                  'QmaxMism','Q_Bus#','Q_BusName','Q_Volt','Q_VoltMagPU','Solution Attempt'])
    elif k == 'd':
        for i, line in enumerate(open(r'K:\AFC Model Solution Logs\log\log_daily.txt')):
            for match in re.finditer(pattern, line):
                #print(line)
                lst+=[[line[3:5],line[7:10],line[13:15],line[17:20],\
                    line[25:30],line[31:38],line[38:51],line[52:56],\
                    line[59:66],line[71:76],line[77:84], line[85:97],\
                    line[97:102],line[105:112],line[112:127]]]
        #frame = pd.DataFrame(lst, columns=['Day','Iterations','Pms','Qms','P_Mismatch','P_Bus#','P_BusName','P_Volt','P_VoltMagPU',\
        #                                  'QmaxMism','Q_Bus#','Q_BusName','Q_Volt','Q_VoltMagPU','Solution Attempt'])
    elif k == 'm':
        for i, line in enumerate(open(r'K:\AFC Model Solution Logs\log\log_monthly.txt')):
            for match in re.finditer(pattern, line):
                #print(line)
                lst+=[[line[5:7],line[9:12],line[15:17],line[19:22],\
                    line[27:32],line[33:40],line[41:53],line[53:58],\
                    line[61:68],line[73:78],line[79:86], line[87:99],\
                    line[99:104],line[107:114],line[114:129]]]
        #frame = pd.DataFrame(lst, columns=['Month','Iterations','Pms','Qms','P_Mismatch','P_Bus#','P_BusName','P_Volt','P_VoltMagPU',\
        #                                  'QmaxMism','Q_Bus#','Q_BusName','Q_Volt','Q_VoltMagPU','Solution Attempt'])
    else:
        'do nothing'
        
    print('solution rows: ' + str(len(lst)))
    #print(lst)
    parse_stop = datetime.datetime.now()
    t = parse_stop - parse_start
    print('parsing time (days, seconds): ' + str(divmod(t.days * 86400 + t.seconds, 60)))
    df = pd.DataFrame(lst, columns=['Day','Iterations','Pms','Qms','P_Mismatch','P_Bus#','P_BusName','P_Volt','P_VoltMagPU',\
                                      'QmaxMism','Q_Bus#','Q_BusName','Q_Volt','Q_VoltMagPU','Solution Attempt'])
    if len(file_out)>1:
        df.to_csv(file_out, index=False, delim_whitespace=True) 
    else:
        return df


    
# -------------------------------------------------------------------
# The one function that rules them all.
# -------------------------------------------------------------------
def soln3_fixer(from_server=False, testing=False):
    import os
    import shutil
    import sys
    import pandas as pd
    
    '''    
    global dir_source 
    dir_source = r'K:\AFC Model Solution Logs\log'
    global soln_text 
    soln_text = 'amb_solve' # 'amb_solve3.dir  '\d\d\ amb_solve\d\.dir'
    global regex_file_pattern
    # regex_file_patternoptions  'h*log_*ly.txt' , 'd*log_*ly.txt' , 
    #                            'w*log_*ly.txt' , 'm*log_*ly.txt' ,
    #                            'y*log_*ly.txt' , '*log_*ly.txt'
    regex_file_pattern = '*log_*ly.txt'
    global dir_working 
    dir_working = r'c:/temp/'
    global dir_out
    dir_out = dir_working    # r'K:\AFC Model Solution Logs'
    global file_out
    file_out = 'Hourly Solutions.csv'  # file_out = path.join(dir_out, file_out)
    global col_specs  #set =None to auto-calc column widths
    col_specs = soln_col_specs()
    global soln_col_cnt
    soln_col_cnt = len(col_specs['h'])
    col_specs = soln_col_specs()
    '''
	
    sys_path_append('psy_readme.txt') # imports psyops library
    global psyops
    import psyops
    from psyops import psy_file as fm  # Advena's python library for lazy power systems engineers

    sys_path_append('soln_config.py') # imports soln3_fixer library
    global soln3_fixer
    import soln3_fixer
    global soln3_config
    import soln3_config as cfg
    
     # initialize
    soln_rpt=[]
	# Find the log files
    log_file_list = fm.find_files(root_path=cfg.dir_source, \
                               pattern=cfg.regex_file_pattern, \
                               recursive=False) # get list of log files
    server_file_list = [os.path.join(cfg.dir_source, fname) for fname in log_file_list]
    working_file_list = [os.path.join(cfg.dir_working, fname) for fname in log_file_list]
    # copy the files to dir_working
    soln_rpt=[]
    for i in range(len(server_file_list)):
        try:
            srv_file = server_file_list[i]
            wrk_file = working_file_list[i]
        except:
            if testing: print('Unexpected Error')
            return [-1,'Error.  Unable to read from file list.']
        if from_server: 
            try:
                os.remove(wrk_file)
                if testing: print("deleted old file : " + str(wrk_file))
            except:
                "do nothing"
            try:
                shutil.copy(srv_file, dir_working)
                if testing: print("copied: " + str(srv_file) + " to " + str(wrk_file)    )
            except:
                return [-2,'Unable to copy log file from server to working directory.']
        else:
            if testing: print("using files in working directory")

        # get the solution summary table from the log file (near the bottom)
        k = wrk_file.split("_")[-1][0]
        soln_rpt += [soln_report_from_log_file(wrk_file, regex_str=cfg.regex_soln3, file_out=cfg.file_out)]
    
    return soln_rpt


# -------------------------------------------------------------------
# allow execution as command line script: python soln3_fixer.py
# -------------------------------------------------------------------
if __name__ == "__main__":
    #def read_config(cfg_file = 'soln3_fixer.cfg'):
    '''
    read_config - reads in configuration file if run from command line
    Default execution is of soln3_fixer.cfg in current directory.  All
    items from read_config are set to global variables.

    The soln3_fixer.cfg file is expected in:
    {python install folder}\Lib\site-packages\psyops\soln3_fixer.cfg.
    
    '''
    soln3_fixer(False, testing=False)
    
#print('soln3_fixer(True)')
#soln3_fixer(False, testing=True)