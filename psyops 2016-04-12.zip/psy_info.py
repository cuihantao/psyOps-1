# -*- coding: utf-8 -*-
"""
Created on Fri Apr 08 14:38:55 2016

@author: advena
"""

def psy_path(file_name='psy_readme.txt'):
    import sys
    from os import listdir
    from fnmatch import filter    
    for sf in [r'Lib\site-packages\psyops', 'Lib', '']:
        try:
            ret=[]
            for base, dirs, files in os.walk(os.path.join(sys.exec_prefix, sf)):
                goodfiles = filter(files, file_name)
                ret.extend(os.path.join(base, f) for f in goodfiles)
            return ret[0][:-15]
        except:
            'try again'

def psy_import():
    import sys
    from os import listdir
    from fnmatch import filter    
    py_path = psy_path()    
    try:
        path.index(py_path)
        return True
    except:
        try:
            path.append(py_path)
            return True
        except:
            print('Unable to to import required psyops library.  Script will fail.')
            return False

# -------------------------------------------------------------------
# allow execution as command line script: python soln3_fixer.py
# -------------------------------------------------------------------
if __name__ == "__main__":
    psy_import()