# -*- coding: utf-8 -*-
'''


'''


    
def filter_file_lines(file_in, regex_str):
    #import pandas as pd
    import re
    lines = []  # pandas.DataFrame()
    print ("regex: ", regex_str)
    pattern = re.compile(regex_str)
    
    for line in open(file_in):
        for match in re.finditer(pattern, line):
            lines+=[line]
    
    return lines   #df.to_list()  #pandas.DataFrame(lst)
def filter_file_lines_test():
    file_in = r'K:\AFC Model Solution Logs\log\log_hourly48.txt'
    regex_str = '\d\d\ amb_solve\d\.dir' 
    print(filter_file_lines(file_in, regex_str))

def find_files(root_path, pattern='**', recursive=False):
    from fnmatch import filter
    import os
    try:
        if recursive:
            ret = []
            for base, dirs, files in os.walk(root_path):
                goodfiles = filter(files, pattern)
                ret.extend(os.path.join(base, f) for f in goodfiles)
            return ret
        else:
            return filter(os.listdir(root_path), pattern)
    except:
        print 'Error: find_files(' + str(root_path) + ', ' + str(pattern) + ') failed.'
        return []  #return empty array to assure calling code does not fail
def find_files_test():
    print('Non-recurive: c:\temp')
    ret = find_files(r'C:\temp', '*.*', False)
    print(ret)
    print('')
    print 'Recurive: c:\temp'
    ret = find_files(r'C:\temp', '*.*', True)
    print(ret)

def test_all():
    filter_file_lines_test()
    print('')
    print('')
    find_files_test()