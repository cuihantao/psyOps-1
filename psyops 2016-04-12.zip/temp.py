# -*- coding: utf-8 -*-
"""
Created on Thu Apr 07 16:44:30 2016

@author: advena
"""

# the column specs if first col len = 0 
'''
lst = [[0, 5], [5, 10], [10, 20], [20, 30], [30, 38], [38, 42], [42, 44], \
       [44, 56], [56, 66], [66, 76], [76, 84], [84, 89], [89, 102], \
       [102, 112], [112, 127], [127, 130]]
lst2 = [[item[0]-int(lst[0][1]),item[1]-int(lst[0][1])] for item in lst]  
lst2[0][0] = 0
lst2
[[0, 0], [0, 5], [5, 15], [15, 25], [25, 33], [33, 37], [37, 39], [39, 51], [51, 61], [61, 71], [71, 79], [79, 84], [84, 97], [97, 107], [107, 122], [122, 125]]
'''


def soln_table_col_specs(line1_str):
    lst = [[0, 0], [0, 5], [5, 15], [15, 25], [25, 33], [33, 37], [37, 39], \
           [39, 51], [51, 61], [61, 71], [71, 79], [79, 84], [84, 97], \
           [97, 107], [107, 122], [122, 125]]
    i = len(line_list[0].split(' ')[0]) + 2 #get width of 1st item in col1 and add 2 (since hour goes from hour1 to hour186)
    #print(i)
    lst = [[item[0]+i,item[1]+i] for item in lst]
    lst[0][0] = 0
    return lst
def soln_table_col_specs_test():
    line_list = ['day1   asdfasd adsfasdf adfasdf']
    line1 = line_list[0]
    print soln_table_col_specs(line1)
soln_table_col_specs_test()